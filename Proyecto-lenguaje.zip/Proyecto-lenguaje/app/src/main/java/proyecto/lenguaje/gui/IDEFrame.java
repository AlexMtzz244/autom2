package proyecto.lenguaje.gui;

import proyecto.lenguaje.lexer.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.List;

public class IDEFrame extends JFrame {
    private JTextArea codeEditor;
    private JTextArea lineNumbers;
    private JTextArea outputArea;
    private JButton lexButton, saveButton, saveAsButton;
    private JFileChooser fileChooser;
    private File currentFile;

    public IDEFrame() {
        setTitle("Mini IDE - Evaluación de Lenguaje Haskell");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 600);
        setLayout(new BorderLayout());

        // Crear editor con números de línea
        codeEditor = new JTextArea();
        lineNumbers = new JTextArea("1");
        lineNumbers.setEditable(false);
        lineNumbers.setBackground(Color.LIGHT_GRAY);
        lineNumbers.setFont(new Font("monospaced", Font.PLAIN, 12));
        codeEditor.setFont(new Font("monospaced", Font.PLAIN, 12));
        
        // Panel para editor con números de línea
        JPanel editorPanel = new JPanel(new BorderLayout());
        editorPanel.add(lineNumbers, BorderLayout.WEST);
        editorPanel.add(codeEditor, BorderLayout.CENTER);
        
        // Sincronizar scroll entre números de línea y editor
        JScrollPane codeScroll = new JScrollPane(editorPanel);
        codeScroll.getVerticalScrollBar().addAdjustmentListener(e -> updateLineNumbers());
        
        // Agregar listener para actualizar números de línea
        codeEditor.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updateLineNumbers(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updateLineNumbers(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updateLineNumbers(); }
        });

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane outputScroll = new JScrollPane(outputArea);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(outputScroll, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        lexButton = new JButton("Validar Léxicamente");
        saveButton = new JButton("Guardar Cambios");
        saveAsButton = new JButton("Guardar Como");
        buttonPanel.add(lexButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(saveAsButton);
        rightPanel.add(buttonPanel, BorderLayout.SOUTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, codeScroll, rightPanel);
        splitPane.setDividerLocation(500);
        add(splitPane, BorderLayout.CENTER);

        fileChooser = new JFileChooser();

        lexButton.addActionListener(e -> runLexicalAnalysis());
        saveButton.addActionListener(e -> saveFile());
        saveAsButton.addActionListener(e -> saveFileAs());
        
        updateLineNumbers(); // Inicializar números de línea
    }

    private void updateLineNumbers() {
        String text = codeEditor.getText();
        int lines = text.split("\n").length;
        if (text.isEmpty()) lines = 1;
        
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= lines; i++) {
            sb.append(i).append("\n");
        }
        lineNumbers.setText(sb.toString());
    }

    private void runLexicalAnalysis() {
        HaskellLexer lexer = new HaskellLexer();
        String code = codeEditor.getText();
        List<Token> tokens = lexer.tokenize(code);
        StringBuilder sb = new StringBuilder();
        
        int errorCount = 0;
        for (Token t : tokens) {
            sb.append(t.toString()).append("\n");
            if (t.getType() == Token.Type.ERROR) {
                errorCount++;
            }
        }
        
        sb.append("\n--- RESUMEN ---\n");
        sb.append("Total de tokens: ").append(tokens.size()).append("\n");
        sb.append("Errores léxicos: ").append(errorCount).append("\n");
        
        if (errorCount > 0) {
            sb.append("\n--- ERRORES ENCONTRADOS ---\n");
            for (Token t : tokens) {
                if (t.getType() == Token.Type.ERROR) {
                    sb.append("ERROR: Carácter inválido '").append(t.getValue())
                      .append("' en línea ").append(t.getLine())
                      .append(", posición ").append(t.getPosition()).append("\n");
                }
            }
        }
        
        outputArea.setText(sb.toString());
    }

    private void saveFile() {
        if (currentFile == null) {
            saveFileAs();
            return;
        }
        try (FileWriter fw = new FileWriter(currentFile)) {
            fw.write(codeEditor.getText());
            outputArea.setText("Archivo guardado: " + currentFile.getAbsolutePath());
        } catch (IOException ex) {
            outputArea.setText("Error al guardar: " + ex.getMessage());
        }
    }

    private void saveFileAs() {
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            currentFile = fileChooser.getSelectedFile();
            saveFile();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new IDEFrame().setVisible(true));
    }
}
