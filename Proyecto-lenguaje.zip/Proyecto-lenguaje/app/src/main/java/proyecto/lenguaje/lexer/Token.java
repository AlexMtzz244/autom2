package proyecto.lenguaje.lexer;

public class Token {
    public enum Type {
        IDENTIFIER, NUMBER, OPERATOR, KEYWORD, STRING, CHAR, SYMBOL, ERROR
    }

    private final Type type;
    private final String value;
    private final int position;
    private final int line;

    public Token(Type type, String value, int position, int line) {
        this.type = type;
        this.value = value;
        this.position = position;
        this.line = line;
    }

    public Type getType() { return type; }
    public String getValue() { return value; }
    public int getPosition() { return position; }
    public int getLine() { return line; }

    @Override
    public String toString() {
        return String.format("[%s] '%s' (línea: %d, pos: %d)", type, value, line, position);
    }
}
