package proyecto.lenguaje.lexer;

import java.util.*;
import java.util.regex.*;

public class HaskellLexer {
    private static final Map<Token.Type, Pattern> patterns = new LinkedHashMap<>();
    static {
        patterns.put(Token.Type.KEYWORD, Pattern.compile("\\b(let|in|if|then|else|case|of|data|type|where|module|import|deriving|class|instance|newtype|do|default|foreign|forall|hiding|qualified|as|family|role|pattern|static|stock|anyclass|via)\\b"));
        patterns.put(Token.Type.IDENTIFIER, Pattern.compile("[a-zA-Z_][a-zA-Z0-9_']*"));
        patterns.put(Token.Type.NUMBER, Pattern.compile("[0-9]+(\\.[0-9]+)?"));
        patterns.put(Token.Type.STRING, Pattern.compile("\"([^\"\\n]|\\\\.)*\""));
        patterns.put(Token.Type.CHAR, Pattern.compile("'([^'\\n]|\\\\.)'"));
        patterns.put(Token.Type.OPERATOR, Pattern.compile("(\\+\\+|\\.|::|->|<-|<=|>=|==|/=|&&|\\|\\||[-+*/=<>:|&!])+"));
        patterns.put(Token.Type.SYMBOL, Pattern.compile("[(){}\\[\\],;]"));
    }

    public List<Token> tokenize(String input) {
        List<Token> tokens = new ArrayList<>();
        int pos = 0;
        int line = 1;
        while (pos < input.length()) {
            boolean matched = false;
            char currentChar = input.charAt(pos);
            
            if (Character.isWhitespace(currentChar)) {
                if (currentChar == '\n') {
                    line++;
                }
                pos++;
                continue;
            }
            
            // Verificar si es un carácter inválido para identificadores
            if (currentChar == '@' || currentChar == '#' || currentChar == '$' || currentChar == '%' || 
                currentChar == '^' || currentChar == '~' || currentChar == '?' || currentChar == '`') {
                tokens.add(new Token(Token.Type.ERROR, String.valueOf(currentChar), pos, line));
                pos++;
                continue;
            }
            
            for (Map.Entry<Token.Type, Pattern> entry : patterns.entrySet()) {
                Matcher m = entry.getValue().matcher(input.substring(pos));
                if (m.lookingAt()) {
                    tokens.add(new Token(entry.getKey(), m.group(), pos, line));
                    pos += m.end();
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                tokens.add(new Token(Token.Type.ERROR, String.valueOf(input.charAt(pos)), pos, line));
                pos++;
            }
        }
        return tokens;
    }
}
